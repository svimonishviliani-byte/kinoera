// Bundled demo catalog + Supabase row <-> app-shape helpers.
// This file has no React/JSX in it so the seed script (scripts/seed.mjs)
// can import it directly with plain Node.

/* =========================================================================
   MOCK DATA
========================================================================= */
export const GENRES = ["დრამა", "კომედია", "თრილერი", "აქცია", "საბავშვო", "დოკუმენტური", "ისტორიული", "ფანტასტიკა", "საშინელება", "მელოდრამა", "დეტექტივი", "სამხედრო"];

export const IMG = (seed, w, h) => `https://picsum.photos/seed/${seed}/${w}/${h}`;

export const DEMO_VIDEO = "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4";

export const rawMovies = [
  { id: "m1", title: "ბნელი ქუჩების ჩრდილი", year: 2023, genres: ["დრამა", "თრილერი"], rating: 8.4, duration: 118, director: "დავით მაისურაძე", cast: ["ნინო ქავთარაძე", "გიორგი ლომიძე", "სალომე ჯავახია"], description: "ძველი თბილისის ერთ ღამეში ერთმანეთს კვეთენ სამი უცხო ადამიანის ბედი — ყოფილი პოლიციელი, ახალგაზრდა მხატვარი და ქუჩის მუსიკოსი, რომლებმაც არ იციან, რომ ერთი და იმავე საიდუმლოს ეძებენ.", trending: true, popular: true, newlyAdded: false, recommended: true },
  { id: "m2", title: "მთის სიჩუმე", year: 2022, genres: ["დრამა", "ისტორიული"], rating: 9.0, duration: 132, director: "ეკა ბერიძე", cast: ["ლევან წიკლაური", "მარიამ გელაშვილი"], description: "მთიან სოფელში, სადაც დრო თითქოს გაჩერდა, ახალგაზრდა მასწავლებელი ცდილობს შეინარჩუნოს იმედი თემში, რომელსაც თანდათან ტოვებენ ახალგაზრდები.", trending: false, popular: true, newlyAdded: false, recommended: true },
  { id: "m3", title: "ქალაქის სულები", year: 2024, genres: ["საშინელება", "თრილერი"], rating: 7.2, duration: 101, director: "ირაკლი ხუციშვილი", cast: ["თამარ ღლონტი", "ბექა სვანიძე"], description: "ძველი ბინის ახალი მაცხოვრებლები აღმოაჩენენ, რომ კედლებს ახსოვთ ყველაფერი, რაც აქ მომხდარა ბოლო ას წელიწადში.", trending: true, popular: false, newlyAdded: true, recommended: false },
  { id: "m4", title: "ზღვის პირას", year: 2021, genres: ["მელოდრამა"], rating: 8.1, duration: 108, director: "ნატა ჩხაიძე", cast: ["გვანცა მელაძე", "ალექსანდრე ცერცვაძე"], description: "ორი ყოფილი მეგობრის შემთხვევითი შეხვედრა ბათუმის სანაპიროზე ხელახლა უღვივებს გრძნობებს, რომლებიც წლების წინ დაუსრულებელი დარჩა.", trending: false, popular: true, newlyAdded: false, recommended: true },
  { id: "m5", title: "უკანასკნელი მატარებელი", year: 2025, genres: ["აქცია", "დეტექტივი"], rating: 7.8, duration: 124, director: "გიგა ფხაკაძე", cast: ["ვახტანგ ონიანი", "ეთერ ბასილაშვილი"], description: "დეტექტივი გზა-გასაყარზეა — ღამის უკანასკნელ მატარებელზე მიმალული დამნაშავე უნდა დაიჭიროს, სანამ ის საზღვარს გადალახავს.", trending: true, popular: true, newlyAdded: true, recommended: false },
  { id: "m6", title: "ღვინის გზაზე", year: 2020, genres: ["კომედია", "დრამა"], rating: 7.5, duration: 96, director: "სოფო არჩვაძე", cast: ["ზურაბ კახიძე", "ლელა დათუნაშვილი"], description: "კახეთში დაბრუნებული ძმები ცდილობენ გადაარჩინონ მამის მევენახეობა, თუმცა თავად ერთმანეთს ვერ ეთანხმებიან არაფერში.", trending: false, popular: false, newlyAdded: false, recommended: true },
  { id: "m7", title: "თოვლის ქვეშ", year: 2023, genres: ["დრამა", "საოჯახო"], rating: 8.6, duration: 112, director: "დავით მაისურაძე", cast: ["ნინო ქავთარაძე", "თემურ ალადაშვილი"], description: "სვანეთის ერთ სოფელში მოხუცი ბაბუა და მისი შვილიშვილი ერთმანეთს პოულობენ ისეთ ზამთარში, რომელიც სოფელს გარეთა სამყაროსგან წყვეტს.", trending: false, popular: true, newlyAdded: true, recommended: true },
  { id: "m8", title: "შუშის ქარხანა", year: 2019, genres: ["დეტექტივი", "თრილერი"], rating: 8.0, duration: 119, director: "ირაკლი ხუციშვილი", cast: ["ბექა სვანიძე", "მაკა ცინცაძე"], description: "დახურული ქარხნის ტერიტორიაზე ნაპოვნი უცნაური საგანი ჟურნალისტს გადაწყვეტილების წინაშე აყენებს — გამოაქვეყნოს სიმართლე, თუ დაიცვას საკუთარი ოჯახი.", trending: false, popular: false, newlyAdded: false, recommended: false },
  { id: "m9", title: "ცისარტყელას მეორე მხარეს", year: 2024, genres: ["საბავშვო", "ფანტასტიკა"], rating: 8.9, duration: 94, director: "ნატა ჩხაიძე", cast: ["ანა ბარნოვი", "ლუკა თოფურია"], description: "მცირეწლოვანი გოგონა შემთხვევით აღმოაჩენს კარს, რომელიც ცისარტყელას მეორე მხარეს მდებარე სამყაროში მიდის — იქ, სადაც ფერები საუბრობენ.", trending: true, popular: true, newlyAdded: true, recommended: true },
  { id: "m10", title: "დათვის ხეობა", year: 2018, genres: ["სამხედრო", "ისტორიული"], rating: 7.9, duration: 141, director: "გიგა ფხაკაძე", cast: ["ვახტანგ ონიანი", "ზურაბ კახიძე"], description: "მეორე მსოფლიო ომის დროს, ხეობაში ჩაკეტილი მცირერიცხოვანი რაზმი ცდილობს გადარჩენას და უკან დაბრუნებას.", trending: false, popular: false, newlyAdded: false, recommended: false },
  { id: "m11", title: "ღამის ცვლა", year: 2025, genres: ["თრილერი", "დრამა"], rating: 7.3, duration: 103, director: "სოფო არჩვაძე", cast: ["ლელა დათუნაშვილი", "თემურ ალადაშვილი"], description: "საავადმყოფოს ღამის ცვლაზე მომუშავე ექთანი ერთ ღამეს ისეთ არჩევანის წინაშე დგება, რომელიც მის მთელ ცხოვრებას შეცვლის.", trending: false, popular: false, newlyAdded: true, recommended: false },
  { id: "m12", title: "სამი დღე თბილისში", year: 2022, genres: ["კომედია", "მელოდრამა"], rating: 7.6, duration: 99, director: "ეკა ბერიძე", cast: ["გვანცა მელაძე", "ბექა სვანიძე"], description: "საზღვარგარეთიდან სამი დღით ჩამოსული ქალი ცდილობს იპოვოს ადამიანი, რომელმაც ათი წლის წინ წერილი გაუგზავნა და პასუხი არასოდეს მიუღია.", trending: false, popular: true, newlyAdded: false, recommended: true },
  { id: "m13", title: "რკინის ჩიტები", year: 2021, genres: ["ფანტასტიკა", "აქცია"], rating: 8.3, duration: 127, director: "დავით მაისურაძე", cast: ["ალექსანდრე ცერცვაძე", "მაკა ცინცაძე"], description: "მომავლის თბილისში, სადაც ცაში მექანიკური ჩიტები დაფრინავენ საზოგადოებრივი მეთვალყურეობისთვის, ახალგაზრდა ინჟინერი პროგრამის ბზარს პოულობს.", trending: true, popular: false, newlyAdded: true, recommended: false },
  { id: "m14", title: "წყლის ხაზი", year: 2020, genres: ["დოკუმენტური"], rating: 8.7, duration: 88, director: "ნატა ჩხაიძე", cast: ["თხრობა: გიორგი ლომიძე"], description: "დოკუმენტური ფილმი შავი ზღვის სანაპირო ზონის მეთევზეების ცხოვრებაზე, თაობიდან თაობამდე გადაცემულ ტრადიციებზე.", trending: false, popular: false, newlyAdded: false, recommended: true },
  { id: "m15", title: "უკანასკნელი ფურცელი", year: 2026, genres: ["დრამა"], rating: 8.5, duration: 115, director: "ირაკლი ხუციშვილი", cast: ["სალომე ჯავახია", "ლევან წიკლაური"], description: "ხანდაზმული მწერალი, რომელსაც უკანასკნელი რომანის დაწერა უჭირს, ახალგაზრდა რედაქტორთან საუბრებში საკუთარ წარსულს იხსენებს.", trending: true, popular: true, newlyAdded: true, recommended: true },
];

export function makeEpisodes(seasonNum, count, titleBase) {
  return Array.from({ length: count }, (_, i) => ({
    id: `s${seasonNum}e${i + 1}`,
    number: i + 1,
    title: `${titleBase} — ეპიზოდი ${i + 1}`,
    description: "ამბავი გრძელდება უცნაური შემობრუნებით, რომელიც პერსონაჟებს ახალი გამოწვევების წინაშე აყენებს.",
    duration: 38 + (i % 4) * 3,
    videoUrl: DEMO_VIDEO,
  }));
}

export const rawSeries = [
  { id: "s1", title: "ვერცხლის ხიდი", year: 2023, genres: ["დრამა", "თრილერი"], rating: 8.8, director: "დავით მაისურაძე", cast: ["ნინო ქავთარაძე", "გიორგი ლომიძე"], description: "ორი ოჯახი, რომლებსაც ერთი ხიდი აშორებთ და აერთიანებთ ერთდროულად — თაობათა საიდუმლოებების ისტორია.", trending: true, popular: true, newlyAdded: false, recommended: true,
    seasons: [{ number: 1, episodes: makeEpisodes(1, 8, "ვერცხლის ხიდი") }, { number: 2, episodes: makeEpisodes(2, 6, "ვერცხლის ხიდი") }] },
  { id: "s2", title: "შავი ზღვის კარიბჭე", year: 2022, genres: ["დეტექტივი", "თრილერი"], rating: 8.2, director: "გიგა ფხაკაძე", cast: ["ვახტანგ ონიანი", "ეთერ ბასილაშვილი"], description: "ბათუმის საპორტო ქალაქში სპეციალური რაზმის დეტექტივი კონტრაბანდის ქსელს ეძებს.", trending: false, popular: true, newlyAdded: true, recommended: false,
    seasons: [{ number: 1, episodes: makeEpisodes(1, 10, "შავი ზღვის კარიბჭე") }] },
  { id: "s3", title: "ოჯახური რეცეპტი", year: 2024, genres: ["კომედია"], rating: 7.9, director: "სოფო არჩვაძე", cast: ["ზურაბ კახიძე", "ლელა დათუნაშვილი"], description: "სამი და, რომლებიც ერთმანეთს არ ეთანხმებიან არაფერში, მემკვიდრეობით ღებულობენ ოჯახურ რესტორანს.", trending: true, popular: true, newlyAdded: true, recommended: true,
    seasons: [{ number: 1, episodes: makeEpisodes(1, 12, "ოჯახური რეცეპტი") }] },
  { id: "s4", title: "მეფის ქალაქი", year: 2021, genres: ["ისტორიული", "დრამა"], rating: 9.1, director: "ეკა ბერიძე", cast: ["ლევან წიკლაური", "მარიამ გელაშვილი", "სალომე ჯავახია"], description: "შუა საუკუნეების საქართველოში, სამეფო კარზე ძალაუფლებისთვის ბრძოლა და ერთგულების ფასი.", trending: false, popular: true, newlyAdded: false, recommended: true,
    seasons: [{ number: 1, episodes: makeEpisodes(1, 8, "მეფის ქალაქი") }, { number: 2, episodes: makeEpisodes(2, 8, "მეფის ქალაქი") }, { number: 3, episodes: makeEpisodes(3, 5, "მეფის ქალაქი") }] },
  { id: "s5", title: "ღამის ცვლის გმირები", year: 2025, genres: ["დრამა", "საოჯახო"], rating: 8.0, director: "ირაკლი ხუციშვილი", cast: ["თამარ ღლონტი", "ბექა სვანიძე"], description: "საავადმყოფოს პერსონალის ცხოვრება ღამის ცვლებზე — იმედი, დაღლილობა და ერთმანეთის მხარდაჭერა.", trending: true, popular: false, newlyAdded: true, recommended: false,
    seasons: [{ number: 1, episodes: makeEpisodes(1, 6, "ღამის ცვლის გმირები") }] },
  { id: "s6", title: "მაღალმთიანეთის კანონი", year: 2020, genres: ["დრამა", "სამხედრო"], rating: 8.4, director: "გიგა ფხაკაძე", cast: ["ვახტანგ ონიანი", "ზურაბ კახიძე"], description: "მთის სოფლების ძველი წეს-ჩვეულებები დღევანდელობასთან ხვდება კონფლიქტში.", trending: false, popular: false, newlyAdded: false, recommended: true,
    seasons: [{ number: 1, episodes: makeEpisodes(1, 7, "მაღალმთიანეთის კანონი") }] },
  { id: "s7", title: "სკოლის ეზო", year: 2023, genres: ["საბავშვო", "კომედია"], rating: 8.6, director: "ნატა ჩხაიძე", cast: ["ანა ბარნოვი", "ლუკა თოფურია"], description: "მეხუთეკლასელების თავგადასავლები სკოლაში და მის ეზოში — მეგობრობა, ხრიკები და პირველი გაკვეთილები ცხოვრებაზე.", trending: true, popular: true, newlyAdded: true, recommended: true,
    seasons: [{ number: 1, episodes: makeEpisodes(1, 10, "სკოლის ეზო") }, { number: 2, episodes: makeEpisodes(2, 10, "სკოლის ეზო") }] },
  { id: "s8", title: "მომავლის კვალი", year: 2026, genres: ["ფანტასტიკა", "თრილერი"], rating: 7.7, director: "დავით მაისურაძე", cast: ["ალექსანდრე ცერცვაძე", "მაკა ცინცაძე"], description: "ახლო მომავლის თბილისში, ხელოვნური ინტელექტის მკვლევარი პასუხისმგებელია გადაწყვეტილებაზე, რომელიც კაცობრიობის ბედს განსაზღვრავს.", trending: false, popular: false, newlyAdded: true, recommended: false,
    seasons: [{ number: 1, episodes: makeEpisodes(1, 6, "მომავლის კვალი") }] },
  { id: "s9", title: "ვაზის ძირას", year: 2019, genres: ["დრამა", "მელოდრამა"], rating: 8.3, director: "სოფო არჩვაძე", cast: ["გვანცა მელაძე", "თემურ ალადაშვილი"], description: "კახური ოჯახის სამი თაობა ერთ მამულში — სიყვარული, დაპირისპირება და მიწასთან კავშირი.", trending: false, popular: true, newlyAdded: false, recommended: true,
    seasons: [{ number: 1, episodes: makeEpisodes(1, 9, "ვაზის ძირას") }] },
  { id: "s10", title: "საიდუმლო არქივი", year: 2022, genres: ["დეტექტივი", "დრამა"], rating: 8.5, director: "ეკა ბერიძე", cast: ["ეთერ ბასილაშვილი", "ბექა სვანიძე"], description: "ძველი საარქივო დოკუმენტების მკვლევარი შემთხვევით წააწყდება საქმეს, რომელიც ათწლეულების წინანდელ დანაშაულს ააშკარავებს.", trending: true, popular: false, newlyAdded: false, recommended: false,
    seasons: [{ number: 1, episodes: makeEpisodes(1, 8, "საიდუმლო არქივი") }, { number: 2, episodes: makeEpisodes(2, 4, "საიდუმლო არქივი") }] },
];

/* attach images */
rawMovies.forEach((m) => { m.type = "movie"; m.poster = IMG(m.id + "-p", 500, 750); m.backdrop = IMG(m.id + "-b", 1600, 900); m.videoUrl = DEMO_VIDEO; });
rawSeries.forEach((s) => { s.type = "series"; s.poster = IMG(s.id + "-p", 500, 750); s.backdrop = IMG(s.id + "-b", 1600, 900); });


/* =========================================================================
   SUPABASE <-> APP SHAPE
   The `movies` table stores both movies and series (a `type` column tells
   them apart). These two functions are the only place that needs to know
   about that column mapping.
========================================================================= */
export function rowToItem(row) {
  return {
    id: row.id,
    type: row.type,
    title: row.title,
    year: row.year,
    genres: row.genres || [],
    rating: Number(row.rating) || 0,
    duration: row.duration ?? undefined,
    director: row.director || "",
    cast: row.cast_members || [],
    description: row.description || "",
    poster: row.poster || IMG(row.id + "-p", 500, 750),
    backdrop: row.backdrop || IMG(row.id + "-b", 1600, 900),
    videoUrl: row.video_url || DEMO_VIDEO,
    trending: !!row.trending,
    popular: !!row.popular,
    newlyAdded: !!row.newly_added,
    recommended: !!row.recommended,
    seasons: row.seasons || undefined,
  };
}

export function itemToRow(item) {
  return {
    id: item.id,
    type: item.type,
    title: item.title,
    year: item.year,
    genres: item.genres,
    rating: item.rating,
    duration: item.type === "movie" ? (item.duration || null) : null,
    director: item.director,
    cast_members: item.cast,
    description: item.description,
    poster: item.poster,
    backdrop: item.backdrop,
    video_url: item.videoUrl,
    trending: !!item.trending,
    popular: !!item.popular,
    newly_added: !!item.newlyAdded,
    recommended: !!item.recommended,
    seasons: item.type === "series" ? (item.seasons || []) : null,
  };
}

