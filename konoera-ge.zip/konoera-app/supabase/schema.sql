-- ============================================================================
-- Konoera.ge — Supabase schema
-- Run this once in your project's SQL editor (Supabase dashboard -> SQL Editor
-- -> New query -> paste -> Run). Safe to re-run only if the tables don't
-- already exist; it will error on a second run because the tables/policies
-- already exist — that's expected and fine.
-- ============================================================================

-- 1) profiles: one row per registered user, extends built-in auth.users
--    with a display name and a role ("user" by default, "admin" once you
--    promote someone).
create table public.profiles (
  id uuid references auth.users on delete cascade primary key,
  email text,
  display_name text,
  role text not null default 'user' check (role in ('user', 'admin')),
  created_at timestamptz default now()
);

-- Automatically create a profile row whenever someone signs up.
create function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, display_name)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data ->> 'display_name', split_part(new.email, '@', 1))
  );
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- 2) movies: holds BOTH movies and series (the `type` column tells them
--    apart). `seasons` is only used for series and stores season/episode
--    data as JSON, matching the shape the app already works with.
create table public.movies (
  id text primary key,
  type text not null default 'movie' check (type in ('movie', 'series')),
  title text not null,
  year int not null,
  genres text[] not null default '{}',
  rating numeric not null default 0,
  duration int,
  director text,
  cast_members text[] default '{}',
  description text,
  poster text,
  backdrop text,
  video_url text,
  trending boolean default false,
  popular boolean default false,
  newly_added boolean default false,
  recommended boolean default false,
  seasons jsonb,
  created_at timestamptz default now()
);

-- 3) Row Level Security — this is what actually protects the data.
--    Without RLS, anyone with your anon key could write to these tables
--    directly, bypassing the app entirely.
alter table public.profiles enable row level security;
alter table public.movies enable row level security;

-- profiles: a user can only see/update their own row.
create policy "profiles are viewable by owner"
  on public.profiles for select
  using (auth.uid() = id);

create policy "profiles are updatable by owner"
  on public.profiles for update
  using (auth.uid() = id);

-- movies: everyone can read the catalog, including logged-out visitors.
create policy "movies are viewable by everyone"
  on public.movies for select
  using (true);

-- movies: only rows belonging to a profile with role = 'admin' may write.
create policy "movies are insertable by admins"
  on public.movies for insert
  with check (
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

create policy "movies are updatable by admins"
  on public.movies for update
  using (
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

create policy "movies are deletable by admins"
  on public.movies for delete
  using (
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

-- ============================================================================
-- After running this file:
--
-- 1) Register a normal account on the live site (or via Supabase Auth ->
--    Users -> Add user in the dashboard).
-- 2) Promote that account to admin by running, in the SQL editor:
--
--      update public.profiles set role = 'admin' where email = 'you@example.com';
--
-- 3) (Optional, recommended for a fast solo launch) In Authentication ->
--    Providers -> Email, turn OFF "Confirm email" so new accounts can log
--    in immediately without clicking an email link. Turn it back on later
--    if you open registration to the public.
--
-- 4) Create a public Storage bucket named "posters" (Storage -> New bucket,
--    toggle "Public") so the admin panel's poster upload button works.
-- ============================================================================
