// One-time helper: pushes the bundled demo catalog (the same 15 movies +
// 10 series you already see in local/demo mode) into your Supabase
// `movies` table, so switching to Supabase doesn't start you from zero.
//
// Run once, after you've run supabase/schema.sql:
//
//   SUPABASE_URL=https://xxxx.supabase.co \
//   SUPABASE_SERVICE_ROLE_KEY=your-service-role-key \
//   node scripts/seed.mjs
//
// The service role key is found in Supabase -> Project Settings -> API.
// It bypasses Row Level Security, which is exactly why it must ONLY be
// used locally, in a terminal, never in the app itself, and never
// committed anywhere — it is not the same as the anon key used in .env.

import { createClient } from "@supabase/supabase-js";
import { rawMovies, rawSeries, itemToRow } from "../src/data/catalog.js";

const url = process.env.SUPABASE_URL;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!url || !serviceKey) {
  console.error(
    "Missing env vars. Run as:\n" +
      "  SUPABASE_URL=... SUPABASE_SERVICE_ROLE_KEY=... node scripts/seed.mjs"
  );
  process.exit(1);
}

const supabase = createClient(url, serviceKey);

async function main() {
  const rows = [...rawMovies, ...rawSeries].map(itemToRow);
  console.log(`Seeding ${rows.length} titles...`);
  const { error } = await supabase.from("movies").upsert(rows);
  if (error) {
    console.error("Seed failed:", error.message);
    process.exit(1);
  }
  console.log("Done — the demo catalog is now in your Supabase database.");
}

main();
